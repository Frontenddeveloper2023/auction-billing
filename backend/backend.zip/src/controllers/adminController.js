const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const Admin = require("../models/admin");
const Session = require("../models/session");
const sendEmail = require("../utils/sendEmail");
const { cleanupExpiredSessions } = require("../controllers/sessionController");
const { getTemplateSubject } = require("./emailTemplateController");

// ─── ADMIN EMAIL OTP LOGIN ───────────────────────────────────────────────────

// 1. Send OTP for Admin Login
exports.sendLoginOtp = async (req, res) => {
  try {
    const { identifier } = req.body; // Can be username or email
    if (!identifier || !identifier.trim()) {
      return res.status(400).json({ status: false, message: "Username or email is required" });
    }

    const trimmed = identifier.trim();
    const admin = await Admin.findOne({
      $or: [{ username: trimmed }, { email: trimmed.toLowerCase() }],
    });

    if (!admin) {
      return res.status(404).json({ status: false, message: "Account not found" });
    }

    if (admin.role === "sub-admin" && admin.status !== "Active") {
      return res.status(403).json({
        status: false,
        message: "Access denied. Account is not active.",
      });
    }

    // Generate 6-digit OTP valid for 5 minutes
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    admin.otp = otp;
    admin.otpExpires = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes
    await admin.save();

    const emailSubject = await getTemplateSubject(
      "admin_login_otp",
      "Your Login Verification Code"
    );

    const emailContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Login Verification</title>
    </head>
    <body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td align="center">
            <table width="600" cellpadding="0" cellspacing="0" border="0" style="background:#ffffff; margin:40px 0; border-radius:8px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.06);">
              <tr>
                <td align="center" style="background:#F39C12; padding:25px; color:#ffffff;">
                  <h1 style="margin:0; font-size:24px;">${process.env.COMPANY_NAME || "AuctionBilling"}</h1>
                  <p style="margin:5px 0 0; font-size:14px;">Admin Portal Login Verification</p>
                </td>
              </tr>
              <tr>
                <td style="padding:30px; color:#333333;">
                  <h2 style="margin-top:0; color:#1e293b;">Hello ${admin.username},</h2>
                  <p>Your one-time login verification code (OTP) is:</p>
                  <div style="text-align:center; margin:30px 0;">
                    <span style="font-size:34px; font-weight:bold; letter-spacing:8px; color:#F39C12; padding:14px 28px; background:#fffaf0; border-radius:8px; border:2px dashed #F39C12; display:inline-block;">
                      ${otp}
                    </span>
                  </div>
                  <p style="color:#64748b; font-size:14px;">This code is valid for <strong>5 minutes</strong>. Do not share this OTP with anyone for security purposes.</p>
                  <p style="color:#64748b; font-size:14px;">If you did not attempt to log in, please ignore this email or contact support immediately.</p>
                  <br/>
                  <p>Regards,<br/>${process.env.COMPANY_NAME || "AuctionBilling"} Security Team</p>
                </td>
              </tr>
              <tr>
                <td align="center" style="background:#f1f1f1; padding:20px; font-size:12px; color:#777;">
                  <p style="margin:0;">© ${new Date().getFullYear()} ${process.env.COMPANY_NAME || "AuctionBilling"}. All rights reserved.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>
    `;

    await sendEmail(admin.email, emailSubject, emailContent);

    // Return masked email for user confirmation
    const maskedEmail = admin.email.replace(/^(.)(.*)(@.*)$/, (_, a, b, c) => a + "*".repeat(b.length) + c);

    res.status(200).json({
      status: true,
      message: `OTP sent to ${maskedEmail}`,
      email: admin.email,
    });
  } catch (error) {
    console.error("Admin sendLoginOtp error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

// 2. Verify OTP for Admin Login
exports.verifyLoginOtp = async (req, res) => {
  try {
    const { identifier, otp } = req.body;
    if (!identifier || !otp) {
      return res.status(400).json({ status: false, message: "Identifier and OTP are required" });
    }

    const trimmed = identifier.trim();
    const admin = await Admin.findOne({
      $or: [{ username: trimmed }, { email: trimmed.toLowerCase() }],
    });

    if (!admin) {
      return res.status(404).json({ status: false, message: "Account not found" });
    }

    if (admin.role === "sub-admin" && admin.status !== "Active") {
      return res.status(403).json({
        status: false,
        message: "Access denied. Account is not active.",
      });
    }

    if (!admin.otp || admin.otp !== otp.trim()) {
      return res.status(400).json({ status: false, message: "Invalid OTP code" });
    }

    if (!admin.otpExpires || new Date() > new Date(admin.otpExpires)) {
      return res.status(400).json({ status: false, message: "OTP has expired. Please request a new one." });
    }

    // Clear OTP after successful verification
    admin.otp = null;
    admin.otpExpires = null;
    await admin.save();

    await cleanupExpiredSessions("Admin");

    // ─── Check for existing active sessions (allow max 2 devices) ─────────────
    const activeSessions = await Session.find({
      userId: admin._id,
      userType: "Admin",
      isActive: true,
    }).sort({ lastActivity: 1 });

    if (activeSessions.length >= 2) {
      return res.status(409).json({
        status: false,
        alreadyLogged: true,
        message:
          "Maximum login limit reached (already logged in on 2 devices). After 1 hour of inactivity, you will be logged out.",
        loggedInSince: activeSessions[0].createdAt,
        lastActivity: activeSessions[0].lastActivity,
      });
    }

    const sessionId = crypto.randomBytes(16).toString("hex");
    const token = jwt.sign(
      { id: admin._id, role: admin.role, sessionId },
      process.env.JWT_SECRET,
      { expiresIn: "1d" },
    );

    await Session.create({
      sessionId,
      userId: admin._id,
      userType: "Admin",
      token,
      lastActivity: new Date(),
      isActive: true,
    });

    res.status(200).json({
      status: true,
      message: "Login successful",
      token,
      sessionId,
      data: {
        username: admin.username,
        email: admin.email,
        role: admin.role,
        id: admin._id,
        permissions: admin.permissions,
      },
    });
  } catch (error) {
    console.error("Admin verifyLoginOtp error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

// Keep exports.login backward compatible just in case
exports.login = exports.verifyLoginOtp;

exports.updateProfie = async (req, res) => {
  try {
    const { username, email, otp } = req.body;
    console.log(req.user);
    const admin = await Admin.findOne({ _id: req.user.id });
    if (!admin)
      return res.status(400).json({ status: false, message: "User not found" });

    const existingUser = await Admin.findOne({
      $or: [{ username }, { email }],
      _id: { $ne: req.user.id },
    });

    if (existingUser) {
      if (existingUser.username === username) {
        return res
          .status(400)
          .json({ status: false, message: "Username is already in use" });
      }
      if (existingUser.email === email) {
        return res
          .status(400)
          .json({ status: false, message: "Email is already in use" });
      }
    }

    if (email && email !== admin.email) {
      if (!otp) {
        return res
          .status(400)
          .json({ status: false, message: "OTP is required to change email" });
      }
      if (admin.otp !== otp || admin.otpExpires < Date.now()) {
        return res
          .status(400)
          .json({ status: false, message: "Invalid or expired OTP" });
      }
      // OTP is valid, clear it
      admin.otp = undefined;
      admin.otpExpires = undefined;
    }

    admin.username = username;
    admin.email = email;
    await admin.save();
    res
      .status(200)
      .json({ status: true, message: "Profile updated successfully", admin });
  } catch (error) {
    console.error("Update profile error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.sendEmailUpdateOtp = async (req, res) => {
  try {
    const { email } = req.body;
    const admin = await Admin.findById(req.user.id);

    if (!admin)
      return res.status(404).json({ status: false, message: "User not found" });

    // Check if new email is already used by another user
    const existingUser = await Admin.findOne({
      email,
      _id: { $ne: req.user.id },
    });
    if (existingUser)
      return res
        .status(400)
        .json({ status: false, message: "Email is already in use" });

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpires = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    admin.otp = otp;
    admin.otpExpires = otpExpires;
    await admin.save();

    const emailContent = `
<!DOCTYPE html>
<html>
<body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, sans-serif;">
  <div style="max-width:600px; margin:40px auto; background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
    <div style="background:#f39c12; padding:25px; color:#ffffff; text-align:center;">
      <h1 style="margin:0; font-size:22px;">Update Email Address</h1>
    </div>
    <div style="padding:30px; color:#333;">
      <p>Hello ${admin.username},</p>
      <p>You requested to update your email address. Use the OTP below to confirm the change. Valid for 5 minutes.</p>
      <div style="text-align:center; margin:30px 0;">
        <span style="font-size:32px; font-weight:bold; letter-spacing:6px; color:#f39c12; padding:12px 25px; background:#f9f9f9; border-radius:8px; border:2px dashed #f39c12; display:inline-block;">
          ${otp}
        </span>
      </div>
    </div>
  </div>
</body>
</html>
`;

    const otpSubject = await getTemplateSubject(
      "admin_email_update_otp",
      "Update Email OTP"
    );
    await sendEmail(email, otpSubject, emailContent);
    res
      .status(200)
      .json({ status: true, message: "OTP sent to your new email" });
  } catch (error) {
    console.error("Send email update OTP error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.updatePassword = async (req, res) => {
  try {
    const hashed = await bcrypt.hash(req.body.password, 10);

    await Admin.updateOne({ _id: req.user.id }, { password: hashed });

    res
      .status(200)
      .json({ status: true, message: "Password updated successfully" });
  } catch (error) {
    console.error("Update password error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.getAdmin = async (req, res) => {
  try {
    const admin = await Admin.findById(req.user.id).select("-password");
    if (!admin)
      return res.status(404).json({ status: false, message: "User not found" });

    res.status(200).json({ status: true, admin });
  } catch (error) {
    console.error("Get admin error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.verifyPassword = async (req, res) => {
  try {
    const admin = await Admin.findById(req.user.id);
    if (!admin)
      return res.status(404).json({ status: false, message: "User not found" });

    const isMatch = await bcrypt.compare(req.body.password, admin.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "currect password not match" });
    }

    res.status(200).json({
      status: true,
      message: "currect password is correct",
      currectPassword: true,
    });
  } catch (error) {
    console.error("Verify password error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

//sub admin
exports.createSubAdmin = async (req, res) => {
  try {
    let { username, email, status, name } = req.body;
    username = username || name;

    if (!username)
      return res
        .status(400)
        .json({ status: false, message: "Username is required" });

    const adminNameExists = await Admin.findOne({ username });
    if (adminNameExists)
      return res
        .status(400)
        .json({ status: false, message: "Name is already in use" });

    const adminEmailExists = await Admin.findOne({ email });
    if (adminEmailExists)
      return res
        .status(400)
        .json({ status: false, message: "Email is already in use" });

    const password = crypto.randomBytes(4).toString("hex");
    const hashed = await bcrypt.hash(password, 10);
    const newAdmin = new Admin({
      username,
      password: hashed,
      email,
      role: "sub-admin",
      status,
      permissions: {
        vendorAdd: false,
        subscriptionAccess: false,
        passwordChange: false,
      },
      createdBy: req.user?.id,
      updatedBy: req.user?.id,
    });
    await newAdmin.save();

    // Send email
    const subAdminCreatedSubject = await getTemplateSubject(
      "sub_admin_account_created",
      "Sub Admin Account Created"
    );
    await sendEmail(
      email,
      subAdminCreatedSubject,
      `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <title>Account Created</title>
  </head>
  <body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, sans-serif;">
    
    <!-- Main Wrapper -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td align="center">

          <!-- Email Container -->
          <table width="600" cellpadding="0" cellspacing="0" border="0" 
                 style="background:#ffffff; margin:40px 0; border-radius:8px; overflow:hidden;">

            <!-- Header -->
            <tr>
              <td align="center" 
                  style="background:#f39c12; padding:25px; color:#ffffff;">
                <h1 style="margin:0; font-size:24px;">
                 ${process.env.COMPANY_NAME}
                </h1>
                <p style="margin:5px 0 0; font-size:14px;">
                  Sub Admin Account Created
                </p>
              </td>
            </tr>

            <!-- Body -->
            <tr>
              <td style="padding:30px; color:#333333;">
                <h2 style="margin-top:0;">Hello ${username},</h2>

                <p>
                  Your Sub Admin account has been successfully created.
                  Below are your login details:
                </p>

                <table width="100%" cellpadding="8" cellspacing="0" 
                       style="background:#f8f9fa; border-radius:6px;">
                  <tr>
                    <td><strong>Username:</strong></td>
                    <td>${username}</td>
                  </tr>
                  <tr>
                    <td><strong>Email:</strong></td>
                    <td>${email}</td>
                  </tr>
                  <tr>
                    <td><strong>Password:</strong></td>
                    <td>${password}</td>
                  </tr>
                </table>

                <!-- Button -->
                <div style="text-align:center; margin-top:25px;">
                  <a href="${(process.env.CLIENT_URL || "http://localhost:5173/auction-billing-system").replace(/\/$/, "")}/saas-admin" 
                     style="background:#f39c12; color:#ffffff; 
                            padding:12px 25px; text-decoration:none; 
                            border-radius:5px; font-weight:bold;">
                    Login Now
                  </a>
                </div>
              </td>
            </tr>


            <!-- Footer -->
            <tr>
              <td align="center" 
                  style="background:#f1f1f1; padding:20px; font-size:12px; color:#777;">
                <p style="margin:0;">
                  © ${new Date().getFullYear()} ${process.env.COMPANY_NAME}. All rights reserved.
                </p>
                <p style="margin:5px 0 0;">
                  If you did not request this account, please contact support immediately.
                </p>
              </td>
            </tr>

          </table>

        </td>
      </tr>
    </table>

  </body>
  </html>
  `,
    );

    res.status(200).json({
      status: true,
      message: "Sub-admin created successfully",
      newAdmin,
    });
  } catch (error) {
    console.error("Create sub-admin error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.getSubAdmins = async (req, res) => {
  try {
    const subAdmins = await Admin.find({ role: "sub-admin" }).select(
      "-password",
    );
    res.status(200).json({ status: true, subAdmins });
  } catch (error) {
    console.error("Get sub-admins error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.updateSubAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    let { username, email, status, permissions, name, password } = req.body;
    username = username || name;

    const subAdmin = await Admin.findById(id);
    if (!subAdmin || subAdmin.role !== "sub-admin") {
      return res
        .status(404)
        .json({ status: false, message: "Sub-admin not found" });
    }

    if (username && username !== subAdmin.username) {
      const nameExists = await Admin.findOne({ username });
      if (nameExists)
        return res
          .status(400)
          .json({ status: false, message: "Name is already in use" });
    }

    if (email && email !== subAdmin.email) {
      const emailExists = await Admin.findOne({ email });
      if (emailExists)
        return res
          .status(400)
          .json({ status: false, message: "Email is already in use" });
    }

    if (username) subAdmin.username = username;
    if (email) subAdmin.email = email;
    if (status) subAdmin.status = status;
    if (permissions)
      subAdmin.permissions = { ...subAdmin.permissions, ...permissions };

    // Ensure we don't accidentally update the password this way
    if (password) {
      subAdmin.password = await bcrypt.hash(password, 10);
    }

    subAdmin.updatedBy = req.user?.id;
    await subAdmin.save();

    // Invalidate existing sessions so changes (permissions, status) take effect immediately
    await Session.updateMany(
      { userId: id, userType: "Admin", isActive: true },
      { isActive: false },
    );

    // Send email notification for update
    const subAdminUpdatedSubject = await getTemplateSubject(
      "sub_admin_account_updated",
      "Sub Admin Account Updated"
    );
    await sendEmail(
      subAdmin.email,
      subAdminUpdatedSubject,
      `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <title>Account Updated</title>
  </head>
  <body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
        <td align="center">
          <table width="600" cellpadding="0" cellspacing="0" border="0" 
                 style="background:#ffffff; margin:40px 0; border-radius:8px; overflow:hidden;">
            <tr>
              <td align="center" 
                  style="background:#f39c12; padding:25px; color:#ffffff;">
                <h1 style="margin:0; font-size:24px;">
                 ${process.env.COMPANY_NAME || "AuctionBilling"}
                </h1>
                <p style="margin:5px 0 0; font-size:14px;">
                  Sub Admin Account Updated
                </p>
              </td>
            </tr>
            <tr>
              <td style="padding:30px; color:#333333;">
                <h2 style="margin-top:0;">Hello ${username},</h2>

                <p>
                  Your Sub Admin account has been successfully created.
                  Below are your login details:
                </p>

                <table width="100%" cellpadding="8" cellspacing="0" 
                       style="background:#f8f9fa; border-radius:6px;">
                  <tr>
                    <td><strong>Username:</strong></td>
                    <td>${username}</td>
                  </tr>
                  <tr>
                    <td><strong>Email:</strong></td>
                    <td>${email}</td>
                  </tr>
                  <tr>
                    <td><strong>Password:</strong></td>
                    <td>${password ? password : "<i>(Unchanged)</i>"}</td>
                  </tr>
                </table>
                <p>
                  Your Sub Admin account details or permissions have been updated by the administrator.
                </p>
                <div style="text-align:center; margin-top:25px;">
                  <a href="${(process.env.CLIENT_URL || "http://localhost:5173/auction-billing-system").replace(/\/$/, "")}/saas-admin" 
                     style="background:#f39c12; color:#ffffff; 
                            padding:12px 25px; text-decoration:none; 
                            border-radius:5px; font-weight:bold;">
                    Review Account
                  </a>
                </div>
              </td>
            </tr>
            <tr>
              <td align="center" 
                  style="background:#f1f1f1; padding:20px; font-size:12px; color:#777;">
                <p style="margin:0;">
                  © ${new Date().getFullYear()} ${process.env.COMPANY_NAME || "AuctionBilling"}. All rights reserved.
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
  </html>
      `,
    );

    res.status(200).json({
      status: true,
      message: "Sub-admin updated successfully",
      subAdmin,
    });
  } catch (error) {
    console.error("Update sub-admin error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.deleteSubAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const subAdmin = await Admin.findOneAndDelete({
      _id: id,
      role: "sub-admin",
    });

    if (!subAdmin) {
      return res
        .status(404)
        .json({ status: false, message: "Sub-admin not found" });
    }

    // Invalidate all sessions for this sub-admin
    await Session.updateMany(
      { userId: id, userType: "Admin", isActive: true },
      { isActive: false },
    );

    // Send delete email
    const subAdminDelSubject = await getTemplateSubject(
      "sub_admin_account_deleted",
      "Account Deleted"
    );
    await sendEmail(
      subAdmin.email,
      subAdminDelSubject,
      `
  <!DOCTYPE html>
  <html>
  <body style="margin:0; padding:0; background:#f4f6f8; font-family:Arial;">
    <table width="100%" align="center">
      <tr>
        <td align="center">
          <table width="600" style="background:#ffffff; margin:40px 0; border-radius:8px; overflow:hidden;">
            
            <tr>
              <td style="background:#e74c3c; padding:25px; color:#ffffff;" align="center">
                <h2 style="margin:0;">Account Deleted</h2>
              </td>
            </tr>

            <tr>
              <td style="padding:30px; color:#333;">
                <p>Hello ${subAdmin.username},</p>
                <p>
                  Your Sub Admin account has been deleted by the administrator.
                </p>
                <p>
                  If you believe this was done by mistake, please contact support.
                </p>
              </td>
            </tr>

            <tr>
              <td align="center" style="background:#f1f1f1; padding:15px; font-size:12px; color:#777;">
                © ${new Date().getFullYear()} ${process.env.COMPANY_NAME}. All rights reserved.
              </td>
            </tr>

          </table>
        </td>
      </tr>
    </table>
  </body>
  </html>
  `,
    );

    res
      .status(200)
      .json({ status: true, message: "Sub-admin deleted successfully" });
  } catch (error) {
    console.error("Delete sub-admin error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const adminId = req.user.id;

    const admin = await Admin.findById(adminId);
    if (!admin) {
      return res
        .status(404)
        .json({ status: false, message: "Admin not found" });
    }

    const isMatch = await bcrypt.compare(currentPassword, admin.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "Incorrect current password" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    admin.password = hashedPassword;
    await admin.save();

    res
      .status(200)
      .json({ status: true, message: "Password changed successfully" });
  } catch (error) {
    console.error("Change password error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const admin = await Admin.findOne({ email });

    if (!admin) {
      return res.status(404).json({
        status: false,
        message: "Admin with this email does not exist",
      });
    }

    if (admin.role === "sub-admin" && admin.status !== "Active") {
      return res.status(403).json({
        status: false,
        message: "Account is inactive. Please contact the Admin.",
      });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpires = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    admin.otp = otp;
    admin.otpExpires = otpExpires;
    await admin.save();

    const emailContent = `
<!DOCTYPE html>
<html>
<body style="margin:0; padding:0; background-color:#f4f6f8; font-family:Arial, sans-serif;">
  <div style="max-width:600px; margin:40px auto; background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
    <div style="background:#f39c12; padding:25px; color:#ffffff; text-align:center;">
      <h1 style="margin:0; font-size:22px;">Admin Password Reset</h1>
    </div>
    <div style="padding:30px; color:#333;">
      <p>Hello ${admin.username},</p>
      <p>You requested a password reset. Use the OTP below to reset your password. Valid for 5 minutes.</p>
      <div style="text-align:center; margin:30px 0;">
        <span style="font-size:32px; font-weight:bold; letter-spacing:6px; color:#f39c12; padding:12px 25px; background:#f9f9f9; border-radius:8px; border:2px dashed #f39c12; display:inline-block;">
          ${otp}
        </span>
      </div>
    </div>
  </div>
</body>
</html>
`;

    const adminResetOtpSubject = await getTemplateSubject(
      "admin_password_reset_otp",
      "Admin Password Reset OTP"
    );
    await sendEmail(email, adminResetOtpSubject, emailContent);
    res.status(200).json({ status: true, message: "OTP sent to your email" });
  } catch (error) {
    console.error("Admin forgot password error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};

exports.resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;
    const admin = await Admin.findOne({
      email,
      otp,
      otpExpires: { $gt: Date.now() },
    });

    if (!admin) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid or expired OTP" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    admin.password = hashedPassword;
    admin.otp = undefined;
    admin.otpExpires = undefined;
    await admin.save();

    res
      .status(200)
      .json({ status: true, message: "Password reset successfully" });
  } catch (error) {
    console.error("Admin reset password error:", error);
    res.status(500).json({ status: false, message: "Internal server error" });
  }
};
