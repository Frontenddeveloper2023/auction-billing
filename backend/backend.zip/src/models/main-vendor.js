const mongoose = require("mongoose");

const mainVendorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, default: () => Math.random().toString(36).slice(-10) },
    phone: { type: String, required: true },
    profilePic: { type: String },
    address: { type: String },
    city: { type: String },
    state: { type: String },
    plan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan", required: true },
    requestedPlan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan" },
    upgradeType: { type: String, enum: ["from_today", "after_current"] },
    status: {
      type: String,
      enum: ["Active", "Inactive", "Pending"],
      default: "Active",
    },
    joinedDate: { type: Date, default: Date.now },
    planEndDate: { type: Date },
    totalAuctions: { type: Number, default: 0 },
    revenue: { type: String, default: "0" },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    deletedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
    // isDeleted: { type: Boolean, default: false },
    // deletedAt: { type: Date },
    paymentStatus: {
      type: String,
      enum: ["Pending", "Paid", "Failed"],
      default: "Pending",
    },
    cashfreeOrderId: { type: String },
    cashfreePaymentId: { type: String },
    paidAmount: { type: Number, default: 0 },
    paidAt: { type: Date },
    otp: { type: String },
    otpExpires: { type: Date },
    isPlanExtended: { type: Boolean, default: false },
    planExtendedAt: { type: Date },
  },
  { timestamps: true },
);

module.exports = mongoose.model("MainVendor", mainVendorSchema);
