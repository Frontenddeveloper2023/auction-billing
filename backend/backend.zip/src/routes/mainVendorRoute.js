const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/adminMiddleware");
const mainVendorController = require("../controllers/mainVendorController");
const upload = require("../middleware/uploadMiddleware");

// Route to get all main vendors
router.get("/", authMiddleware, mainVendorController.getMainVendors);

// Auth Routes (Public - Email OTP)
router.post("/send-login-otp", mainVendorController.sendLoginOtp);
router.post("/verify-login-otp", mainVendorController.verifyLoginOtp);
router.post("/signup", mainVendorController.signup);
router.post("/create-payment-order", mainVendorController.createPaymentOrder);
router.post("/verify-and-signup", mainVendorController.verifyAndSignup);
router.post("/login", mainVendorController.login);
router.post("/logout", authMiddleware, mainVendorController.logout);

// Vendor specific routes
router.get("/profile/:id", mainVendorController.getMainVendorProfile);
router.post(
  "/change-password",
  authMiddleware,
  mainVendorController.changePassword,
);
router.post(
  "/create-upgrade-payment-order",
  authMiddleware,
  mainVendorController.createUpgradePaymentOrder,
);
router.post(
  "/verify-and-upgrade-plan",
  authMiddleware,
  mainVendorController.verifyAndUpgradePlan,
);
router.post(
  "/extend-plan",
  authMiddleware,
  mainVendorController.extendVendorPlan,
);

// Route to create a main vendor (Admin only)
router.post(
  "/",
  authMiddleware,
  upload.single("profilePic"),
  mainVendorController.createMainVendor,
);

// Route to update a main vendor
router.put(
  "/:id",
  authMiddleware,
  upload.single("profilePic"),
  mainVendorController.updateMainVendor,
);

// Route to delete a main vendor
router.delete("/:id", authMiddleware, mainVendorController.deleteMainVendor);

// Route to export main vendors
router.post("/export", authMiddleware, mainVendorController.exportMainVendors);

// Route to get main vendor purchases
router.get(
  "/purchases",
  authMiddleware,
  mainVendorController.getMainVendorPurchases,
);

// Route to get specific main vendor purchases
router.get(
  "/:id/purchases",
  authMiddleware,
  mainVendorController.getMainVendorPurchasesById,
);

// Route to get all main vendor purchases export
router.post(
  "/purchases/export",
  authMiddleware,
  mainVendorController.exportMainVendorPurchases,
);

// Route to get all branches under a main vendor
router.get("/branches", authMiddleware, mainVendorController.getBranches);

// Route to get all sellers under a main vendor's branches
router.get("/sellers", authMiddleware, mainVendorController.getSellers);

// Route to get all buyers under a main vendor's branches
router.get("/buyers", authMiddleware, mainVendorController.getBuyers);

// Route to get transaction history under a main vendor's branches
router.get("/history", authMiddleware, mainVendorController.getTransactionHistory);

// Route to get commission records under a main vendor's branches
router.get("/commission", authMiddleware, mainVendorController.getCommissionRecords);

// Route to get dashboard summary
router.get("/dashboard", authMiddleware, mainVendorController.getDashboardSummary);

module.exports = router;
